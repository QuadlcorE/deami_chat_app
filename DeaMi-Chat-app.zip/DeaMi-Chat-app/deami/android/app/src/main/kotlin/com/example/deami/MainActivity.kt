package com.example.deami

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
